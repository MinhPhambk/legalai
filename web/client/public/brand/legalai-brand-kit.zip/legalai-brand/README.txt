LegalAI – brand assets / Bộ nhận diện

legalai-horizontal-*.svg|png  logo ngang / horizontal lockup
legalai-stacked-*.svg|png     logo xếp dọc / stacked lockup
legalai-mark-color.svg|png    biểu tượng vuông / square mark (TECHLAB logo on its red tile)
Variants: color (light backgrounds), color-on-dark (white wordmark). The TECHLAB logo is an official raster – never recolour it.
Clear space = 1/4 of the mark height on every side. Minimum size: mark 16 px, horizontal lockup 96 px wide.
Tech Lab red #B71B21 (logo / tile); UI red #C20B11 (FTU red). Typeface: Be Vietnam Pro (SIL Open Font License).
Do not recolour, stretch, crop, rotate or add effects to the TECHLAB logo; do not combine it with the FTU emblem.
See /brand for the full guideline.
