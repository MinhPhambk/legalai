LegalAI – brand assets / Bộ nhận diện

legalai-horizontal-*.svg|png  logo ngang / horizontal lockup
legalai-stacked-*.svg|png     logo xếp dọc / stacked lockup
legalai-mark-*.svg|png        biểu tượng / mark only
Variants: color (light backgrounds), color-on-dark, black, white, red.
Clear space = 1/4 of the mark height on every side. Minimum size: mark 16 px, horizontal lockup 96 px wide.
Brand red #C20B11 (FTU red). Typeface: Be Vietnam Pro (SIL Open Font License).
Do not recolour, stretch, rotate, add effects or combine the LegalAI mark with the FTU emblem.
See /brand for the full guideline.
